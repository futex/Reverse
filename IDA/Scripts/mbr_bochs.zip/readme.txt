The package files
=====================
* bochsrc: bochs configuration file; Please make sure you set the BXSHARE environment variable.
Otherwise, please edit this file and adjust the pathes
* c.img: disk image
mbr.asm: Sample MBR
mbr.py: A script that acts like a file loader
ida.bat: Run it to compile and launch IDA. Python must be in the path.